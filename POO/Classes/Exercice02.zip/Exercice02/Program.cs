﻿using Exercice02;
using System;

Salarie s1 = new Salarie("Théo", 2500);
Salarie s2 = new Salarie("Zoé", 1300);
Salarie s3 = new Salarie("Bernard", 2400);

Salarie[] salaries = { s1, s2, s3 };

foreach (Salarie s in salaries)
    {
        s.AfficherSalaire();
    }

Salarie.AfficherNombreSalariesEtSalaireTotal();

